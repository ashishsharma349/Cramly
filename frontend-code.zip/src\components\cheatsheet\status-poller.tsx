import { RefreshCw } from 'lucide-react'

// Renders the background job generation status card with loader indicators.
export function StatusPoller({ currentJob }: { currentJob: any }) {
  if (!currentJob) return null

  return (
    <div className="rounded-3xl border border-primary/20 bg-primary/5 p-5 shadow-sm sm:p-6 lg:p-8 flex items-start gap-4 animate-pulse">
      <div className="flex size-10 shrink-0 items-center justify-center rounded-xl bg-primary/10">
        <RefreshCw className="size-5 text-primary animate-spin" />
      </div>
      <div className="space-y-1">
        <h4 className="text-sm font-semibold text-foreground">
          {currentJob.progress || 'Generating Cheatsheet...'}
        </h4>
        <p className="text-xs text-muted-foreground leading-relaxed">
          Building your cheatsheet for <strong className="text-foreground">{currentJob.topic}</strong> ({currentJob.level}). This normally takes 15 to 25 seconds. Please wait.
        </p>
        {currentJob.attempts > 0 && (
          <span className="block text-[11px] font-semibold text-primary mt-1">
            Attempt {currentJob.attempts} of {currentJob.maxAttempts || 3}
          </span>
        )}
      </div>
    </div>
  )
}
