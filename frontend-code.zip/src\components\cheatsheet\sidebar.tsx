import {
  Home,
  FileText,
  Star,
  User,
  Sparkles,
  Sun,
  Moon,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import { Button } from '@/components/ui/button'

const NAV = [
  { id: 'home', label: 'Home', icon: Home },
  { id: 'cheatsheets', label: 'My Cheatsheets', icon: FileText },
  { id: 'favorites', label: 'Favorites', icon: Star },
  { id: 'profile', label: 'Profile', icon: User },
]

type SidebarProps = {
  active: string
  onNavigate: (id: string) => void
  dark: boolean
  onToggleTheme: () => void
}

// Renders the desktop sidebar menu options and theme toggle controls.
export function Sidebar({
  active,
  onNavigate,
  dark,
  onToggleTheme,
}: SidebarProps) {
  return (
    <aside className="hidden w-72 shrink-0 flex-col border-r border-sidebar-border bg-sidebar p-6 lg:flex">
      <div className="flex items-center gap-3">
        <img
          src="/bear-logo.png"
          alt="CheatSheet Generator logo"
          className="size-20 object-contain"
        />
        <div className="text-xl leading-tight font-bold tracking-tight">
          <span className="block text-foreground">CheatSheet</span>
          <span className="block text-primary">Generator</span>
        </div>
      </div>

      <nav className="mt-8 flex flex-col gap-1">
        {NAV.map((item) => {
          const isActive = active === item.id
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => onNavigate(item.id)}
              aria-current={isActive ? 'page' : undefined}
              className={cn(
                'flex items-center gap-3 rounded-xl px-4 py-3 text-sm font-medium transition-colors',
                isActive
                  ? 'bg-primary/10 text-primary'
                  : 'text-muted-foreground hover:bg-secondary hover:text-foreground',
              )}
            >
              <item.icon className="size-5" />
              {item.label}
            </button>
          )
        })}
      </nav>

      <div className="mt-8 rounded-2xl border border-border bg-secondary/50 p-5 text-center">
        <div className="mx-auto flex size-12 items-center justify-center rounded-xl bg-primary/10">
          <Sparkles className="size-6 text-primary" />
        </div>
        <h3 className="mt-3 text-lg leading-snug font-semibold text-balance">
          Save & Organize Your Cheatsheets
        </h3>
        <p className="mt-2 text-[13px] leading-relaxed font-normal text-muted-foreground text-pretty sm:text-base">
          Create an account to save, organize and access your cheatsheets
          anywhere.
        </p>
        <Button className="mt-4 w-full rounded-xl">Sign Up / Log In</Button>
      </div>

      <div className="mt-auto flex items-center justify-between rounded-xl border border-border px-4 py-3">
        <span className="flex items-center gap-2 text-sm font-medium">
          {dark ? (
            <Moon className="size-4 text-primary" />
          ) : (
            <Sun className="size-4 text-primary" />
          )}
          {dark ? 'Dark Mode' : 'Light Mode'}
        </span>
        <button
          type="button"
          role="switch"
          aria-checked={dark}
          aria-label="Toggle dark mode"
          onClick={onToggleTheme}
          className={cn(
            'relative h-6 w-11 rounded-full transition-colors',
            dark ? 'bg-primary' : 'bg-primary/40',
          )}
        >
          <span
            className={cn(
              'absolute top-0.5 size-5 rounded-full bg-card shadow transition-transform',
              dark ? 'translate-x-5' : 'translate-x-0.5',
            )}
          />
        </button>
      </div>
    </aside>
  )
}
